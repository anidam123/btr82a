<?php
$data = json_decode(file_get_contents('php://input'), true);
$mode = isset($data['mode']) ? $data['mode'] : "none";

file_put_contents('../storage/mode.txt', $mode);
echo json_encode(["status" => "ok", "mode" => $mode]);
?>