<?php
$data = json_decode(file_get_contents('php://input'), true);
$amount = isset($data['amount']) ? (int)$data['amount'] : 0;
$balancePath = '../storage/balance.txt';

$current = (int) file_get_contents($balancePath);
$new = $current + $amount;
file_put_contents($balancePath, $new);

echo json_encode(["new_balance" => $new]);
?>