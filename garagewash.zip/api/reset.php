<?php
file_put_contents('../storage/mode.txt', "none");
echo json_encode(["status" => "reset"]);
?>