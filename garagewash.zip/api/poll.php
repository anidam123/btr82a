<?php
$balanceFile = '../storage/balance.txt';
$modeFile = '../storage/mode.txt';

$balance = (int) file_get_contents($balanceFile);
$mode = trim(file_get_contents($modeFile));

if ($mode === 'none' || empty($mode)) {
    echo json_encode(["command" => "00000000,00,00,00,00,0,S"]);
    exit;
}

$modePrices = [
    "voda" => 200,
    "turbo" => 200,
    "xim" => 200,
    "nano" => 200,
    "vosk" => 200,
    "osmos" => 200,
    "warm" => 200
];

$modeCommands = [
    "voda" => "10000110,00,00,00,00,42.5,F",
    "turbo" => "10000110,00,00,00,00,47.5,F",
    "xim" => "00100110,00,99,00,00,27.5,F",
    "nano" => "00010110,99,00,00,00,27.5,F",
    "vosk" => "01000110,00,00,99,00,20.0,F",
    "osmos" => "10000110,00,00,00,00,20.0,F",
    "warm" => "00100110,00,00,00,00,27.5,F"
];

if (!isset($modePrices[$mode])) {
    echo json_encode(["command" => "00000000,00,00,00,00,0,S"]);
    exit;
}

$price = $modePrices[$mode];
$command = $modeCommands[$mode];

if ($balance >= $price) {
    $newBalance = $balance - $price;
    file_put_contents($balanceFile, $newBalance);
    echo json_encode(["command" => $command, "balance" => $newBalance]);
} else {
    file_put_contents($modeFile, "none");
    echo json_encode(["command" => "end_session", "balance" => $balance]);
}
?>